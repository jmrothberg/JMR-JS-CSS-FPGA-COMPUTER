// Finder program disk client. Not instantiated.
//
// Python fsList / fsRead / fsWrite / fsRemove / fsRename are the
// behavioural truth (functional_model/machine.py). This sequencer is
// the RTL shape for that ABI: the same storage strobes as
// jmr_desktop_disk, and a byte port the parent would connect to the
// JS arena. It holds no catalog RAM and no JS heap.
//
// It is not in sim/Makefile or tools/board_flow/vivado_build.tcl.
// exec64 natives 58..63 still fault (sites 5801..5806) until this is
// wired ahead of the desktop in the storage mux. The built-in desktop
// stays in the bitstream until that wiring has an FPGA-SIM F9.
module jmr_finder_fs (
    input  logic        clk,
    input  logic        rst_n,
    input  logic        start,
    input  logic [2:0]  cmd,          // 1 list, 2 read, 3 write, 4 remove, 5 rename
    output logic        busy,
    output logic        done,
    output logic        fs_error,
    output logic [8:0]  count,
    output logic        stor_open,
    output logic        stor_close,
    output logic        stor_dir,
    output logic        stor_next,
    output logic        stor_get,
    output logic [7:0]  stor_name_len,
    input  logic        stor_busy,
    input  logic        stor_done,
    input  logic        stor_err,
    input  logic        stor_eof,
    input  logic [7:0]  stor_line_len,
    input  logic [7:0]  stor_byte,
    input  logic [31:0] stor_file_size,
    input  logic [31:0] stor_dir_size,
    output logic        mem_en,
    output logic        mem_we,
    output logic [15:0] mem_addr,
    output logic [7:0]  mem_wdata,
    input  logic [7:0]  mem_rdata,
    input  logic        mem_gnt,
    // Arena byte the parent would write next clock. List records match
    // _nat_fs_list: nlen, name, u32 size, u16 date, u8 attr, then nlen 0.
    output logic        arena_we,
    output logic [16:0] arena_addr,
    output logic [7:0]  arena_wdata
);
    typedef enum logic [3:0] {
        IDLE, DIR_START, DIR_WAIT, NEXT, NEXT_WAIT, READ, READ_WAIT,
        EMIT, FINISH, UNSUPPORTED
    } state_t;
    state_t state;
    logic [3:0] char_i;
    logic [3:0] name_n;
    logic [3:0] emit_i;
    logic [2:0] emit_kind; // 0 len, 1 name, 2 size, 3 meta
    logic [7:0] name_buf [0:11];
    logic [16:0] ptr;
    logic [31:0] size_q;

    assign busy = state != IDLE;

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            state <= IDLE;
            done <= 1'b0;
            fs_error <= 1'b0;
            count <= 9'd0;
            stor_open <= 1'b0;
            stor_close <= 1'b0;
            stor_dir <= 1'b0;
            stor_next <= 1'b0;
            stor_get <= 1'b0;
            stor_name_len <= 8'd0;
            mem_en <= 1'b0;
            mem_we <= 1'b0;
            mem_addr <= 16'd0;
            mem_wdata <= 8'd0;
            arena_we <= 1'b0;
            arena_addr <= 17'd0;
            arena_wdata <= 8'd0;
            char_i <= 4'd0;
            name_n <= 4'd0;
            emit_i <= 4'd0;
            emit_kind <= 3'd0;
            ptr <= 17'd256;
            size_q <= 32'd0;
        end else begin
            done <= 1'b0;
            stor_open <= 1'b0;
            stor_close <= 1'b0;
            stor_dir <= 1'b0;
            stor_next <= 1'b0;
            stor_get <= 1'b0;
            mem_en <= 1'b0;
            mem_we <= 1'b0;
            arena_we <= 1'b0;
            case (state)
                IDLE: begin
                    if (start && cmd == 3'd1) begin
                        count <= 9'd0;
                        fs_error <= 1'b0;
                        ptr <= 17'd256;
                        state <= DIR_START;
                    end else if (start && cmd != 3'd0) begin
                        // Read, write, remove, and rename reuse LOAD, SAVE,
                        // and one directory-entry rewrite. Those strobes are
                        // not connected here yet, so the command fails loud
                        // instead of reporting an empty success.
                        state <= UNSUPPORTED;
                    end
                end
                DIR_START: if (!stor_busy) begin
                    stor_dir <= 1'b1;
                    state <= DIR_WAIT;
                end
                DIR_WAIT: if (stor_done) begin
                    if (stor_err) begin
                        fs_error <= 1'b1;
                        state <= FINISH;
                    end else state <= NEXT;
                end
                NEXT: if (!stor_busy) begin
                    stor_next <= 1'b1;
                    state <= NEXT_WAIT;
                end
                NEXT_WAIT: if (stor_done) begin
                    if (stor_err || stor_eof || count == 9'd250) begin
                        fs_error <= stor_err;
                        state <= FINISH;
                    end else begin
                        char_i <= 4'd0;
                        name_n <= 4'd0;
                        size_q <= stor_dir_size;
                        state <= READ;
                    end
                end
                // One line-buffer byte per grant. Address in, data next.
                READ: begin
                    mem_en <= 1'b1;
                    mem_addr <= 16'hBB00 + {12'd0, char_i};
                    state <= READ_WAIT;
                end
                READ_WAIT: if (mem_gnt) begin
                    if (char_i < 4'd12) begin
                        name_buf[char_i] <= mem_rdata;
                        name_n <= char_i + 4'd1;
                    end
                    if (char_i + 4'd1 >= stor_line_len[3:0] || char_i == 4'd11) begin
                        emit_kind <= 3'd0;
                        emit_i <= 4'd0;
                        state <= EMIT;
                    end else begin
                        char_i <= char_i + 4'd1;
                        state <= READ;
                    end
                end
                EMIT: begin
                    arena_we <= 1'b1;
                    arena_addr <= ptr;
                    ptr <= ptr + 17'd1;
                    if (emit_kind == 3'd0) begin
                        arena_wdata <= {4'd0, name_n};
                        emit_kind <= 3'd1;
                        emit_i <= 4'd0;
                    end else if (emit_kind == 3'd1) begin
                        arena_wdata <= name_buf[emit_i];
                        if (emit_i + 4'd1 >= name_n) begin
                            emit_kind <= 3'd2;
                            emit_i <= 4'd0;
                        end else emit_i <= emit_i + 4'd1;
                    end else if (emit_kind == 3'd2) begin
                        arena_wdata <= size_q[7:0];
                        size_q <= {8'd0, size_q[31:8]};
                        if (emit_i == 4'd3) begin
                            emit_kind <= 3'd3;
                            emit_i <= 4'd0;
                        end else emit_i <= emit_i + 4'd1;
                    end else begin
                        // Date and attribute are 0 until the storage
                        // engine exports the directory entry's date.
                        arena_wdata <= 8'd0;
                        if (emit_i == 4'd2) begin
                            count <= count + 9'd1;
                            state <= NEXT;
                        end else emit_i <= emit_i + 4'd1;
                    end
                end
                FINISH: begin
                    arena_we <= 1'b1;
                    arena_addr <= ptr;
                    arena_wdata <= 8'd0;
                    done <= 1'b1;
                    state <= IDLE;
                end
                UNSUPPORTED: begin
                    fs_error <= 1'b1;
                    done <= 1'b1;
                    state <= IDLE;
                end
                default: state <= IDLE;
            endcase
        end
    end
endmodule
