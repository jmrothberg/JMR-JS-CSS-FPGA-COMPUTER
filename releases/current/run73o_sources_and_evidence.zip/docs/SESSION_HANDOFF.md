# Session handoff

Words: [README.md — Words used](../README.md#words-used-in-this-project).
**FPGA-SIM** = the chip simulated (Verilator of the same `rtl/*.sv`).
**Glass** = READY, the game, errors. **Fit** = does the design fit the
Nexys Video T200 (365 Block RAM tiles).

This page is **this week’s status** plus the **failed-fix table** (glass
mistakes we must not repeat). Fit numbers: [FPGA_FIT.md](FPGA_FIT.md).
Recurring debug classes: [potential bugs.md](potential%20bugs.md).
**30 pictures/second on the board:** [SYNTH_SLOWDOWN_LEDGER.md](SYNTH_SLOWDOWN_LEDGER.md).

Critical “do not”s: two copies only — see
[README.md — Two copies](../README.md#two-copies-of-every-critical-do-not).
This file is **copy 2** of read-`traces/`-first and **copy 1** of synth
hygiene (copy 2 of hygiene: [FPGA_FIT.md](FPGA_FIT.md) NEVER +
[OLD_RUNS.md](OLD_RUNS.md) taxonomy).

---

## CURRENT STATE

**2026-11-02 run73o completed at 03:02 EST:** the requested new `.bit` is
`build/run73/release/run73o_native_js_speed_WNS+0.000.bit`. It passes fresh
full-route timing, pulse-width, resource and DRC-error gates. The Oct26
run72b remains the standard; no FPGA was programmed. Work is on
`codex/run73-speed`; root RTL matches immutable `build/run73/source_o/`.
The late native-argument XDC guard was moved to supported Tcl (same actual
timing intent); the release was independently requalified with the clean
constraint. Final setup 0.000 ns (rounded, no extra margin), hold +0.040 ns,
87,876 LUTs / 28,045 slices / 353.5 BRAM / 128 DSP. All 123,616 routable nets
are routed; zero setup/hold/pulse failures and DRC errors. DRC warnings and
unchanged timing-coverage warnings remain documented in the full reports.
All 86 framebuffer RAMB36 Port A modes are READ_FIRST.

Compared with identical Oct26 JSH bytes, bounded manual-frame native RTL
DDR-model replays give 2.0050× median PACFAST / 2.3067× DNKF / 2.3557×
DNKFAST, exact final RGB pixels, callback/swap/fault fields and Donkey
final timestamps. This uses the real DDR bridge with modeled 25-cycle reads
without HDMI contention, not measured board FPS. HDMI remains 60 Hz;
Pac-Man p95 gain is 1.7386×. See `build/run73/ddr_comparison_o.json` and
[the complete result](GAME_SPEEDUP_RESULTS.md#run73o-candidate--2026-11-02).
The original uncontrolled startup-tick mismatch and controlled correction
remain honestly retained in `ddr_comparison.json`.

O passed 578 full-suite tests and the separately added timer conversion /
arity test (579 distinct passes). Its five dedicated transfer benches pass
including exact DDR front-image readback and stalls. The unused P variant
also passed a full 579-test suite and all three DDR replays. P's converted
native timer operand adds no measured gain over O, and O qualified first.
P completed synthesis (26 MB DCP) and its resource gates before only its
obsolete implementation/controller was stopped; see
`hardware_p/stopped_after_synth.json`. **No Vivado build remains running.**

The selected hardware uses VM divide-by-three with its actual 5 ns high
pulse, pipelined exact addition, bounded multiply packing, fixed existing
TOS/NOS arithmetic inputs, a single-writer method cache, native argument
registers, packed ImageData, four-frame optional GC (pressure GC immediate),
linear fill/ImageData stepping and staged changed-block display transfers.
No game source, code/art capacity or live heap limit was reduced.

Native operand timing proof: capture at warmup beat 2; beat 3 prepares the
body; first body result capture is the next edge (two VM periods). Only
mapped call_arg_q FFs to VM-clocked endpoints receive setup 2 / hold 1.
Simulation checks operand age and instruction identity. No general opcode,
stack, state or fast-domain multicycle exception was added.

O's initial full route missed setup by 0.272 ns and exposed two cascade
ADDR15 DRC errors from identical placer-generated address-LUT replicas.
Finalization checks the exact LUT5 INIT and every input net before restoring
those two shared address connections. Physical optimization and final
`route_design -preserve` then pass full qualification. No DRC is waived.
The checked recipes are `tools/board_flow/run73o_finalize.tcl`,
`run73o_repair_cascade.tcl`, and `qualify_routed_bit.tcl`. Original and
intermediate DCPs remain under `build/run73/`; release sources and evidence
are bundled beside the bit.

Preserved failed prototypes: G was below the 2× target; J routed with VM
-4.465 ns (dynamic stack selection / remainder packing) and fast -2.337 ns
(dirty lookup feedback); K completed stitched synthesis before its obsolete
controller was stopped; M routed -1.352 ns and its post-route optimization
still missed -1.328 ns; N routed -1.157 ns and optimized/rerouted -0.736 ns.
These remain unqualified even if an implementation directory contains a bit.
No live synthesis was killed and no completed checkpoint was deleted.

Portability: `tools/check_port.py` exposes source/code/API limits;
`tools/prepare_port.py` extracts embedded PNGs to a new directory only after
byte-identical full program/art verification. `portable_DNKFAST.zip` keeps
all six sheets while reducing HTML from 1,388,598 to 43,847 bytes. It fits the
source window, not a complete on-machine language qualification. Remaining
limits include 64 KB source, 80 KB compiled code/trailers, 16 sheets,
2,961,408 art bytes, 16 locals/function, 960 live objects / 32 properties,
arrays up to 128 elements and unsupported browser/JS APIs.

The user explicitly rejected optional security/review choices. Do not ask
that question again; the requested speed work is complete.

**2026-10-26 USB keyboard/mouse failure:** the `USB_MOUSE=1` experiment
disabled the owner's working J15 keyboard and did not satisfy combined
keyboard/mouse support. See the [failed-approach record](NEXYS_USB_KEYBOARD_MOUSE_FAILED.md)
before any further mouse build. It does not supersede the standard below.

## Current standard — 2026-10-26

**run72b_game_speedup_WNS+0.238** is the user-selected standard. Native JS
execution and full game features are retained. The accepted build has
92,273 LUTs / 28,583 slices / 353.5 BRAM, setup +0.238 ns, hold +0.050 ns;
routing took 35m48s. The user reports a working board/tether setup. Numeric
board FPS is not measured; 3.76× Pac-Man / 3.16× Donkey are native RTL gains.

Use [STANDARD_RELEASE.md](STANDARD_RELEASE.md) for the immutable files,
matching card image, checksums, persistent `-f .bit` command, and old binary
archive. New working-tree features do not supersede this release until
separately qualified. In particular, use a named accepted bit rather than
letting a flash target rebuild from changed sources.

The selected regression recorded 549 passed, 12 skipped, 2 existing xfails,
and 1 existing non-strict xpass (564 cases); game preservation replayed
3,240 frames. The old `check_runtime_parity.py` alias assumption is a known
harness issue, not a BATTERY PASS. [Detailed evidence](GAME_SPEEDUP_RESULTS.md).

**Tether fix:** permission denied on channel A was resolved with a temporary
`setfacl` grant and GUI restart. Permanent `dialout` membership needs a new
login. [Bring-up instructions](FPGA_BRINGUP.md).


Live numbers: [FPGA_FIT.md](FPGA_FIT.md) SCOREBOARD. Clock hedge:
[FPGA_FIT.md — If timing fails](FPGA_FIT.md#if-timing-fails-wns--0--slow-the-js-core-not-ddr3).
Board fps plan: [SYNTH_SLOWDOWN_LEDGER.md](SYNTH_SLOWDOWN_LEDGER.md).
exec32: [REMOVING_EXEC32.md](REMOVING_EXEC32.md).

Caps: [FPGA_FIT.md](FPGA_FIT.md) paper budget. Expected-failure counts are release-specific; see the current regression
record above and historical explanations in
[potential bugs.md](potential%20bugs.md).

---

## How we got here (2026-08-19 → 08-21) — one paragraph

Three days, in order: (a) the **glass hunt** — every title-blocking
correctness bug, ending with all five titles playing; (b) a **speed
pass** that cut how many chip heartbeats INVADERS needed for one picture
(18.6 million → 10.6 million) via compiler-proved globals; (c) user-run
triage (DONKEY splash, PACMAN maze, MRDO start key, LIST stall,
Mario→Luigi phantom arrow); (d) the **exec32 cut**, which forced Value64
gaps into the open; (e) the **Port A / fit pass** and V1.0.

Per-bug root causes: **[potential bugs.md](potential%20bugs.md)**. Start at
[RECURRING BUG CLASSES](potential%20bugs.md#recurring-bug-classes--read-this-before-debugging-anything).

---

## 1) Synthesis — the rules that survive every run

This is **copy 1** of synth hygiene (copy 2 is the NEVER table in
[FPGA_FIT.md](FPGA_FIT.md); failure taxonomy [OLD_RUNS.md](OLD_RUNS.md)).

1. **`synth_design` is one step.** There is no **DCP** (Design CheckPoint)
   until `synth_1` hits **100%**. A crash during mapping cannot be resumed —
   the next `make bit` redoes synthesis from scratch.
2. **`bit-fresh` has two opposite meanings.** After a **mid-run crash**:
   never `bit-fresh` / `make clean` — that throws away MIG (Memory Interface
   Generator) / project state you still need. After a **source file-list
   change** (exec32 deleted, or the incremental stitch duplicated the
   framebuffer): `bit-fresh` **is** required, once. That is the 2026-08-21
   next build.
3. **Do not raise the worker count** (`JMR_VIVADO_SYNTH_THREADS`, default
   2) or set `JMR_VIVADO_ALLOW_WIDE=1`. The 2026-08-19 16:17 **OOM** (Out
   Of Memory) was 7 workers on a fat netlist; 08-20 proved 2 workers alone
   does not save a fat netlist either. **The netlist is the variable.**
4. **Do not kill a live synth to attach checkpoint hooks** — hooks only
   fire at step end, so you lose the run and learn nothing.
5. **Watch RSS** (Resident Set Size — how much RAM Vivado is using), not
   the log spinner. Healthy: still printing, RSS holding. Pathological:
   RSS climbing through elaboration with no phase transitions.
6. **`AUTO_INCREMENTAL_CHECKPOINT` stays 0** while RTL is changing. The
   04:11 netlist stitched against a pre-exec32-delete checkpoint and
   **drew the framebuffer twice**. Place cannot fix a garbage netlist.

For scale: 2026-08-19 16:17 OOM’d at technology mapping (RSS 58→114 GB).
The 2026-08-21 V1.0 run **finished synth** then **failed place** — see
[FPGA_FIT.md](FPGA_FIT.md).

---

## 2) FPGA-SIM glass — lessons only

**DONKEY parking at `WAIT_FRAME raf=0` on the title screen is CORRECT JS,
not an RTL bug** — the HTML only re-arms `requestAnimationFrame` once
`gameState=="game"`. An event-driven screen legitimately has no pending
animation frame. Do not “fix” it in silicon; several hours were lost to
this once.

Read `traces/` first (copy 2; copy 1 is `.cursor/rules/use-existing-traces.mdc`).
Newest `traces/*_FPGA-SIM.log`: start at the **end** (fault / trap / typed
lines), then the micro-op tail.

### Failed-fix ledger (do not repeat)

These are **specific** glass mistakes, not a third copy of the Port A law.

| Tried | Why it came back |
|---|---|
| Skip `vobj_gen` / clone heaps | Forbidden — [one-heap-keep-gen](../.cursor/rules/one-heap-keep-gen.mdc) |
| `leave_hold <= (state != EXEC)` in enable=0 else | Deadlock `eip=0` |
| FETCH trampoline taking JUMP while `vctor_takejmp` | field2 width UNDEF |
| Kind-3 `fr = max(e64-1, vcsp_ff)` | Parent leaked to 193; CALL_USER wrote the wrong frame |
| Sticky `hs_m_vcsp` poke always wins over `vcsp_n` | Nested `new` stayed at depth 1 and clobbered Game's frame[0] |
| Delay `hs_m_vcsp` clear until CALL `opnd2` | INVADERS RET 3367 still `ev=0` |
| Wait-beat `vcsp_n = vcsp_hs` including overlay 0 | FOREACH `hs_vcsp(0)` wiped animate |
| Skip `vfn_valid`/`gen` on rAF | Overnight cheat; forbidden |
| **#46** "one timer per frame" (2026-08-19) | **Retracted.** `bind_k` is zeroed by `S_V64_ALLOC`/`S_V64_CTOR_PAD` on every dispatch, so the scan already restarts and all due timers already drain |
| **#50** compiler inliner slot aliasing (2026-08-19) | **Retracted.** RTL env lookup is name-keyed (`hp_key_n`); the a1 slot is only a scan-start hint. Half-vindicated later as **#55** (the hint skipped the prefix) |
| `casestate_q` added to the `vst_raddr` mux for #53 | `casestate_q` lags combo `casestate` by a beat — changed nothing. The real fix was the `hs_st` first-entry guard |
| `hs_ip`/`hs_vsp` on the `S_CONCAT` guard | Unnecessary; reverted. `S_JOIN`'s **is** needed (probe VX2) |

**Keep:** MAKE_FN push `win[1]` + `vst_hold_win`. CALL/CALL_VAL/CALL_METH
**third operand wait**. ALLOC overlay-detect `fr`. Exec identity `ctx_sx`.
Exec `vcsp <= vcsp_n` when the opcode changed depth, raise-only poke when
live. BIND copy from exec **only on IIFE `leave_hold`**. Window `!hs_m_vsp`.
Method-bind GET_PROP sentinel `13'h1FFF`. Do **not** restore `leave_hold`
held in else.

### Do not do these (standing list)

Overnight-go, `bit-fresh` after a mapping crash, the host twin as
FPGA-SIM, skipping gen-match, cloning heaps, restoring a local
`name_blen[]`, rewriting a title's HTML to dodge a VM bug, deleting files
without asking, `leave_hold` held in the enable=0 else, sticky
`hs_m_vcsp` winning over `vcsp_n`, and `stack[i] <=` / `vobj_alloc[i] <=`
anywhere in the parent FSM.

### V1.5 board bring-up handoff (2026-09-01)

EDIT/COMPILE/RUN is LIVE on glass (run-67 bit + the instrumented card).
Cross-lane facts every session needs:

- **storage/COMPILER.HTML + ARTSCAN.HTML now carry `MSG_OFF = 128`** (was
  0 — the console prints from CSTG_HDR_MSG=128; every ?CE was mute since
  birth). Keep 128 in any new chain program.
- **COMPILER.HTML sanitizes the art flag** (`hasArt = (flag === 1)`) and
  guards `artNspr()` ≤ 64 + all `_gw` writes (`dgFail` prints ASCII
  numbers through ?CE). Reason: on the BOARD the arena flag byte (65) read
  back garbage for a no-art title and the art-append path ran a copy off
  the arena end — the long fault-5-at-ip-23 hunt. ROOT CAUSE STILL OPEN
  (console SRAM write → VM read via the DDR3 bridge; sim-invisible).
  Run 68's G-line ({fsite, fault_arg} per fault) is armed for it.
- The CSTG arena is **380,928 words** (CSCR 73,728 + CIMG 307,200, one
  flat byte space). PAL_OFF ≈ 137K is normal.
- The editor is a GAME (running=1 while editing); F2 save prints SAVED.;
  the delete verb is REMOVE. GUI forwards F-keys to titles; F12 = leave.

### RUN 71 — DONE 2026-09-05: run 71c MET WNS +0.311 / WHS +0.025 (daily-driver bit)

**Run 71c (tree 6058dd0, launched 17:16, routed in 19.5 min, published):**
WNS **+0.311** / WHS +0.025, **0 violated endpoints**; worst path now
`u_cons src_i -> state` at +0.311, then MIG reset syncs at +0.315 — the
three retired cones are gone from the top 100. vm_clk +4.268. LUT 90,413
(67.2%), slices 27,093 (80.5%), BRAM 353.5/365 (unchanged), congestion
East level 5 at 111% (placer), no router windows. Synth 8-6849 count 42.
Bit: `build/bits/run71c_csr_parser_cones_bigput_WNS+0.311.bit`; artifacts
in `build/runs/run71c_csr_parser_cones_bigput_WNS+0.311`. Batteries: 189
passed on this tree. Compare 70b: +0.037 thin, LUT 89,381.

Board acceptance (user): F8 put of a big .ARTX (DNKF 1.66 MB ≈ 2.5 min on
the wire + card write, then SAVED; DIR * shows it); a put over a flaky
cable answers ?CK and the retry lands; pull the SD mid-DIR → ?IO, reinsert,
DIR works without power-cycle; STATUS after LOAD; EDIT 10 → ?SN; ESC still
breaks a running game (now one 70 ns beat later); COMPILE of an art title
on the machine draws its sprites (the CART low-byte fix — first time this
path can work); games unchanged.


**Run 71 build ledger (tree 89aee30, Congestion_SpreadLogic_low, incremental,
launched 13:38, routed 14:55, bit refused):** WNS **-0.448** / WHS +0.004,
99 violated endpoints in three cones, none of them run-71 logic:
1. `u_fbscan y_core_q -> sram_addr` (-0.448, 7 of the top 7): compare +
   increment + x320 DSP + 21-bit base add in one 10 ns cycle — the same
   cone run 52's plan named (P1a) and runs 50/52/70b thinned on.
   FIXED for 71b: two register stages (want_q, then want_qq + line_base_q
   from the same sample); prefetch lags the beam 30 ns of a 32 us line.
2. `vm_stop_lat -> u_vm/* CE` (-0.256, ~40 endpoints): the 100 MHz stop
   latch sat at the top of the VM's priority chain, so every register's
   clock-enable was a 10 ns cross-domain cone. FIXED for 71b: `start_q`/
   `stop_q` registered on vm_clk inside the VM (both, so their order is
   unchanged; BREAK lands one 70 ns beat later).
3. `u_sram_br/rdata -> u_vm/vst_wdata[49:48]` (-0.242): the CSR read byte
   entering the value-stack funnel across clk100 -> vm_clk. LEFT ALONE
   (semantics of the ack/hold crossing; run 70b met it at +0.037). If it
   is the sole leader of 71b, the fix is a one-clk100-later ack to the VM
   (`vm_ack_hold_q`) plus a 2-cycle multicycle on the hold data — do it
   with a written argument, not a guess.
Utilization vs 70b: LUT 89,863 (+482), slices 26,646 (-337), BRAM 353.5
(same), LUT-as-memory 2,998; congestion East level 5 at 116% in
CLBLL X54Y44-X85Y75 (placer), no router windows above level 5; vm_clk
met by +4.777. Synth 8-6849 count 42 (70b: 36). Run 71 archived at
build/runs/run71_bigput_crc_sdwd_status_WNS-0.448 (all DCPs + reports);
refused bit kept under build/bits/auto/*WNSFAIL-0.448*.

**Run 71b (tree dafe76e, cones 1+2 retired, launched 15:05, routed in 9
min):** WNS **-0.134** / WHS +0.022, only 4 violated endpoints — leader
`u_cons name_i -> state[1]` (13 levels, 71% route), then the CSR crossing
(-0.077). Two re-place horses from its post_opt.dcp (scratchpad horse.tcl,
archived with the run): **AltSpreadLogic_high MET +0.009 / +0.050** (thin;
worst = the CSR crossing) — published as
`build/bits/run71b_horse_AltSpreadLogic_high_cones_bigput_WNS+0.009_thin.bit`
(flash-for-testing per the run-51 rule; artifacts in build/runs/run71b_horse_*);
ExtraTimingOpt -0.163. The run-71 -0.448 bit is also kept for testing.

**Run 71c (durable margin):** S_CSRAM now captures the bridge byte into
`csr_rd_q` at the ack and finishes one beat later (the crossing is one
register deep; +1 vm beat per CSR op — invisible on a compile), and the
LIST-range parser's `name_i >= line_len` tests are registered
(`ni_end_q`/`ni_end1_q`, consistent with the existing ni_q stall). New
RTL gate test_rtl_run71c_csram_read_write_two_beat (srcByte/srcLen/
stgRead/stgWrite — the compile ABI had NO RTL gate before).

Scope chosen by the user: transfer checking, no lock-ups, STATUS, cheap
language gaps, load-speed instrument; congestion-neutral, no clock change,
capacity growth dropped (the "15 dead BRAM tiles" premise was wrong: the
tag twins and json_mem are live in v64; only tenv_parent is dead).

- **0 editor retirement**: the 23 `C_EDIT_*` inline numbered-line states are
  gone (console 128/128 -> 105/128 before this run's +4). `EDIT n` and typed
  numbered lines answer ?SN; EDITOR.JSH is the editor.
- **A CRC-32 on 0xFC/0xFD**: frame = tag, u32 len, payload, crc32 LE.
  uart_link JSH_C0..C3 verify; mismatch -> `?CK` (reply row 16; reply_sel
  now 5 bits) and the stream is discarded (SOURCE emptied / program not
  started). board_backend appends zlib.crc32 and resends x3 on ?CK. Sim:
  `TETHER_CRCERR 1` injects the flag. Board-side 0xFD path is board-only
  (sim JSHLOAD bypasses the tether).
- **B SD watchdog**: S_SD_WAIT times out (~1.3 s), aborts the SPI master
  (new `abort` input), poisons the mount, answers ?IO. Sim: `SD_HANG 1`.
- **G STATUS**: `NAME <t> LEN <n> [TRUNC] HTML|JS|-- FAULT <site> <arg>`
  (2 console states reusing the LOADED/LIST printers; vm_gdbg -> console).
- **F language-lite**: natives 55 isFinite, 56 isNaN, 57 Math.ceil; alias
  performance.now = Date.now; host compiler desugars a.includes(v) to
  !(a.indexOf(v) < 0). PEER LANE TODO: the on-machine COMPILER.HTML has the
  natInit rows (done here) but still needs the `.includes(` desugar in its
  method-call path (emit indexOf + LOADC 0 + LT + NOT) to match the host.
  e.code and Array.shift/unshift were left out (event construction / RTL
  array ops — run 72 candidates).
- **C instrument**: E line is now `Exxyyzzzz` (zzzz = storage op duration
  x256 clk); flight log prints `op_ms=`. Burst loads NOT built — measure
  first per the approved plan.
- **H**: [Errno 5] on a tether write reopens the USB port once and retries.
- Banner `V2.0 R71`. Gates: CRC put, SD hang, STATUS, natives checksum
  (all pass); full battery on the final binary pending at write time.

### RUN 69 BUG LIST (2026-09-01 — collected, NOT started; user gate)

RTL candidates, in priority order:
1. **VM f64 MUL loses the mantissa at ~2^52-scale operands** — root of the
   w64 constant collapse (0.64->0.5, 640->512). Compiler sidesteps it now;
   the VM corner remains. Needs: FM≡HM extreme-magnitude MUL/MOD/DIV tests,
   then the RTL fix or a documented precision envelope.
2. **Art-flag byte misread** (console SRAM write -> VM read via the DDR3
   bridge; board-only, sim-invisible). Shielded by content sanitation;
   R68's G-line reports {fsite, arg} when it next fires — root-cause then.
3. **Post-exit console drain eats fast typed input** (the type-COMPILE-
   twice effect). Drain should swallow only the terminating key, not a
   time window.
4. Minor: ?CE VM-stopped exit can stream a stale message area; audit
   cmp_msglen handling on the no-cdone path.
5. **`drawImage` dest `clip_u` drops source (2026-09-02).** PYTHON/Chrome
   keep a negative dest origin and skip OOB pixels (source follows the
   full rect). exec64 `clip_u` forces dest x/y to 0 and still DDA from
   source 0 — a billboard with `dx<0` smears the left of the sheet onto
   `x=0` (PYTHON/Chrome clean; FPGA-SIM/BOARD only). `clip_u` was the
   fillRect no-wrap fix (`jmr_js_vm.sv` “no wrap — sparse BOARD bug”);
   blit needs the **visible intersection**: crop `blit_sx/sy/sw/sh` by
   the discarded dest, then clamp. Raster `inb` already skips +overflow.
   Do not rewrite a title to dodge this (standing list).
6. **SAVE-as drops the .ART sidecar** (user 2026-09-01: "we don't want to
   go back to the host"). DESIGN CHOSEN: the HTML declares its art bank —
   `<script data-art="INVF.ART">` beside the sprite shim. ARTSCAN reads it,
   writes the name to the arena NAME_BUF area, cdone(0x86 = "stage this
   named art, then chain to PROGSEL"); the console reuses the mint-as
   name path (jsb_name_src=2) into the existing C_ART_OPEN..C_ART_FLAG
   staging, then loads COMPILER. No declaration → today's by-title-name
   staging (backward compatible). Forks share one art bank, no copies,
   reboot-safe. Host mint (make_sd_image, peer lane) must honor the same
   declaration so host and machine mints agree. Copy-on-save rejected:
   duplicates 100KB+ per fork, single-channel storage makes it awkward.

6. **Big-file put — DONE in run 71 as tag 0xFB** (user 2026-09-04/05: ".artx
   files ALSO, and they are big"). F8's 0xFC put fills the 64 KB SOURCE
   window, so .ART banks over 64 KB (MKBA/MKCA 2.8 MB, DNKF 1.66 MB) were
   skipped "?TR (SOURCE 64K)". Now `runtime/board_backend.py` routes any
   file > SOURCE_MAX through 0xFB: same framing as 0xFC (tag, u32 LE
   length, payload, CRC-32 trailer), `jmr_uart_link` raises
   `jsb_tether_big`, the console stages the bytes into the CART bank
   packed 2 B/word (`C_BIG_TETHER`/`C_BIG_WR`, +2 encodings → 111/128),
   and the typed `SAVE "NAME.ART"` pumps CART to the card through the
   mint's art-append loop (cmp_save_mode + cmp_art_mode with img_len 0,
   reply SAVED). Bad CRC → `?CK`, nothing staged, host resends ×3;
   over 2,961,408 B → SAVE says `?TR`. Sim rpc `BIGFILE <path>`; gates in
   tests/test_console_log.py (roundtrip byte-exact, ?CK-then-recover).
   **Bug found on the way:** the console's bank-1 SRAM client wrote every
   word as `{8'd0, byte}`, so the on-machine art stager (C_ART_GBW) held
   each low byte in `art_word` and never wrote it — an art title compiled
   ON THE MACHINE got a payload with every even byte zeroed (never seen on
   glass because no art title had been board-compiled yet; INV2 said NO
   ART first). Fixed with `src_w16`/`src_wlo` (16-bit write when set);
   the big-put roundtrip gate exercises the same write and append paths.

7. **storage_engine S_SD_WAIT has no watchdog** (board 2026-09-05): a SAVE
   of a 5.5 KB .JSH sat in state 0x09 (waiting on sd_ack) for ~85 s, then
   completed; a following DIR wedged the same way until power-cycle. The
   engine must time out a stuck SD transaction (deselect, re-init at
   INIT_DIV, report ?IO) instead of waiting forever. Card health/seating is
   the likely trigger, the wedge is ours. DONE in run 71 (item B): 27-bit
   watchdog in S_SD_WAIT (~1.3 s) → S_SD_ABORT deselects, the SPI master
   idles, the console gets ?IO; sim rpc `SD_HANG`, gate
   test_rtl_sd_hang_reports_io_and_recovers.

Content/toolchain (not run-gated, mostly peer lane):
- window.open-class browser APIs now stub to 33 in the on-machine compiler
  (574bbb4) — extend natInit as real needs appear.
- Inline-art titles: migrate remaining data-URI titles to .ARTX; that (not
  removing the LIST squash) is what makes every title compile unhacked —
  ARTSCAN refuses inline art regardless of squash.
- On-machine compiler fixes 2026-09-01 night (all in storage/COMPILER.HTML,
  minted): typeof via interned name (not raw 40), window.* unknown APIs →
  stub 33, CALL_VAL argc in arg0, MAKE_FN IIFE bit6. Found by diffing the
  machine-minted .JSH against the host mint at raw-operand level; the
  CALL_VAL bug reproduced in sim as fault 4 at Enter (keydown dispatcher).
